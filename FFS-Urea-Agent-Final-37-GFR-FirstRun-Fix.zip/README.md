# FFS Agent - Final 36

Changes from Final 35:
- Start Agent automatically launches the configured FFS application after saving configuration and requesting the accessibility automation.
- Configuration is saved automatically while editing and when leaving the app; there is no Load Saved Config step.
- Removed the Save Configuration and Load Saved Config action cards from the main UI.
- The settings gear opens Android Accessibility Settings.
- Existing automation flow is retained, including manual OTP, fertilizer removal, Neem selection, retailer search/matching, receiver details, and submission.

Note: APK build was not performed in this runtime because the project does not include gradlew and a complete Android Gradle build environment is unavailable.
